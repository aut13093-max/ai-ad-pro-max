import './globals.css';
export const metadata={title:'AI AD PRO MAX',description:'Vietnam Ecommerce AI Advertising Assistant'};
export default function Layout({children}){return <html lang="zh-CN"><body>{children}</body></html>}
