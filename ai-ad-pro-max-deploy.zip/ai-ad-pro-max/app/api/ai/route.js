export async function POST(req){
 const p=await req.json();
 if(process.env.OPENAI_API_KEY){
  const body={model:process.env.OPENAI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:'You are a Vietnam ecommerce advertising assistant. Return JSON only: {"ads":[{"title":"...","angle":"...","copy":"..."}]} with 5 concise Vietnamese ad variants. Avoid unsupported medical or guaranteed claims.'},{role:'user',content:`Product: ${p.name}; cost: ${p.cost}; price: ${p.price}; budget: ${p.budget}; market: ${p.market}`}],temperature:.7};
  const r=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify(body)}); const j=await r.json();
  try{return Response.json(JSON.parse(j.choices?.[0]?.message?.content||'{"ads":[]}'))}catch{return Response.json({ads:[]})}
 }
 const name=p.name||' sản phẩm'; return Response.json({ads:[['痛点型','解决日常烦恼','Bạn đang gặp vấn đề với '+name+'? Hãy thử giải pháp tiện lợi hơn ngay hôm nay.'],['价格型','价格','Giá tốt, dễ thử, phù hợp nhu cầu mua sắm tại Việt Nam.'],['场景型','使用场景','Thiết kế phù hợp cho cuộc sống hằng ngày. Đặt hàng ngay.'],['效果型','产品价值','Tập trung vào sự tiện lợi và trải nghiệm sử dụng thực tế.'],['促销型','优惠','Ưu đãi trong thời gian giới hạn. Số lượng có hạn, đặt hàng ngay.']].map(x=>({title:x[0],angle:x[1],copy:x[2]}))});}
