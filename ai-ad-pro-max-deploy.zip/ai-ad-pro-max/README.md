# AI AD PRO MAX — Deployable Web App

## Deploy to Vercel
1. Create a GitHub repository and upload this folder.
2. Import the repository into Vercel.
3. Add Environment Variable `OPENAI_API_KEY` (server-side only).
4. Optional: `OPENAI_MODEL=gpt-4o-mini`.
5. Deploy. Vercel gives you an HTTPS URL that works on HONOR/Android and can be added to the home screen.

## Local test
Node.js 18+ required.
`npm install`
`npm run dev`

## Current scope
- Mobile dashboard
- Product inputs
- Vietnamese ad generation API
- Profit/ROAS calculator
- Safe server-side API key pattern

## Production upgrades
Add authentication + Supabase/Postgres, object storage for images, real order data, and Meta/TikTok Ads OAuth/API integrations. Do not place API keys in browser code.
